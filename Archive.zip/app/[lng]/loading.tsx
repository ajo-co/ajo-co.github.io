"use clinet";
import Loader from "@/components/loader";
import React from "react";

export default function Loading() {
  return <Loader loading />;
}
